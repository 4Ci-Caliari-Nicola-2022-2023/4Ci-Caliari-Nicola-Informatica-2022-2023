import wmi
import os
import socket
from datetime import datetime
import sys


def save(path, stringa):
    """
    function for save a string inside a file
    """

    fo = open(path, "a", encoding = "utf-8")
    fo.write(stringa)
    fo.close()
   
   
def log():  
    """
	Write timestamp, platform and socket on trace.log
	"""

    platform = sys.platform
    out = timestamp + "; " + platform+"; "+hostname
    return out

    

def csv():
    
    for usbd in USBDeview
        out += timestamp + "; hostname
        
    save("../" + hostname + "_usbd.csv", out)




if __name__ == "__main__":
    hostname = socket.gethostname()
    timestamp = str(datetime.now())
    save("../log/trace.log", log() + "\n")
    
