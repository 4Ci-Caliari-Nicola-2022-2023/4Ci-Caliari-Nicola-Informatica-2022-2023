# Nome Progetto

![Language](https://img.shields.io/badge/Spellcheck-Pass-green?style=flat) 
![Platform](https://img.shields.io/badge/OS%20platform%20supported-Windows-blue?style=flat)
![Language](https://img.shields.io/badge/Language-Python-yellowgreen?style=flat) 
![Testing](https://img.shields.io/badge/PEP8%20CheckOnline-Passing-green)
![Testing](https://img.shields.io/badge/Test-Pass-green)


## Descrizione

Inserire in questo paragrafo la descrizione del progetto

## Requisiti

Inserire in questo paragrafo i requisiti richiesti per l'esecuzione del progetto

## Esecuzione

Inserire in questo paragrafo la modalità per la/le esecuzioni del progetto

## Tags

Inserire in questo paragrafo i tags che descrivono il progetto

## Author

Lardo Roberto