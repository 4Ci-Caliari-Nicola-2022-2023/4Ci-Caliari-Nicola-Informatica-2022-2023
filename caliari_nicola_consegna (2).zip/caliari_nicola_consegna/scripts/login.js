function myFunction() {
	// Get the value of the input field with id
	var n = document.getElementById("name").value;
	var s = document.getElementById("surname").value;
	var a = document.getElementById("age").value;
	var e = document.getElementById("email").value;
	var p = document.getElementById("password").value;
	var c = document.getElementById("cPassword").value;
	var t = document.getElementById("tNumber").value;
	var pwd_expression = /^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[#?!@$%^&*-])/;
    var letters = /^[A-Za-z]+$/;
    var filter = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
	var numbers = new RegExp("1234567890");

    if (n == '') {
        alert('Please enter your name');
    }
    else if (!letters.test(n)) {
        alert('Name field required only alphabet characters');
	}
	else if (s == '') {
		alert('Please enter your surname');
	}
	else if (!letters.test(s)) {
		alert('Surname field required only alphabet characters');
	}
	else if (a == '') {
		alert('Please enter your age');
	}
    else if (e == '') {
        alert('Please enter your user email id');
    }
    else if (!filter.test(e)) {
        alert('Invalid email');
    }
    else if (t == '') {
        alert('Please enter the telephone number.');
    }
    else if (!number.test(t)) {
        alert('User name field required only numbers');
    }
	else if (t < 10 && t > 10) {
		alert('Invalid telephone number');
	}
    else if (p == '') {
        alert('Please enter Password');
    }
    else if (c == '') {
        alert('Enter Confirm Password');
    }
    else if (!pwd_expression.test(p)) {
		alert('Upper case, Lower case, Special character and Numeric letter are required in Password filed');
    }
    else if (p != c) {
        alert('Password not Matched');
    }
    else if (document.getElementById("password").value.length < 8) {
        alert('Password minimum length is 8');
    }
    else {
        alert('Welcome');

        window.location="index.html";
    }
}