var data = new Date();
var Hh, Mm, Ss, mm;
Hh = data.getHours() + ":";
Mm = data.getMinutes() + ":";
Ss = data.getSeconds();
document.write("Sono le ore " + Hh + Mm + Ss);
document.getElementById('date').style.color = "#000000";